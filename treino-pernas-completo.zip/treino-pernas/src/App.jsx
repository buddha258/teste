import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Checkbox } from '@/components/ui/checkbox.jsx'
import { Moon, Sun, Play, Pause, RotateCcw, Check, RefreshCw, Timer, Dumbbell } from 'lucide-react'
import './App.css'

// Dados dos exercícios
const exerciseData = {
  warmup: {
    title: "Aquecimento",
    exercises: [
      {
        id: "warmup_1",
        name: "Esteira inclinada 6–10 min",
        description: "Caminhada em esteira com inclinação moderada para ativar a circulação e preparar as pernas.",
        image: "/src/assets/treadmill_incline.png",
        beginnerReps: "6-8 min",
        advancedReps: "8-10 min",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      },
      {
        id: "warmup_2", 
        name: "Bike 6–10 min",
        description: "Pedalada leve a moderada para aquecimento cardiovascular e ativação das pernas.",
        image: "https://images.unsplash.com/photo-1544367567-0f2fcb009e0b?w=400&h=300&fit=crop",
        beginnerReps: "6-8 min",
        advancedReps: "8-10 min",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      }
    ]
  },
  blockA: {
    title: "Bloco A – Agachamento Principal (Quadríceps)",
    exercises: [
      {
        id: "block_a_1",
        name: "Leg press 45°",
        description: "Exercício principal para quadríceps. Posicione os pés na largura dos ombros, desça controladamente até 90° e empurre com força.",
        image: "/src/assets/leg_press.jpg",
        beginnerReps: "3x12-15",
        advancedReps: "4x8-12",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      },
      {
        id: "block_a_2",
        name: "Hack squat / Smith squat",
        description: "Alternativa ao leg press. Mantenha o core contraído, desça controladamente e empurre pelos calcanhares.",
        image: "/src/assets/hack_squat.jpg",
        beginnerReps: "3x10-12",
        advancedReps: "4x6-10",
        videoUrl: "https://www.youtube.com/watch?v=Whp712OHPl8"
      }
    ]
  },
  blockB: {
    title: "Bloco B – Hinge de Posterior (Posterior de Coxa/Glúteo)",
    exercises: [
      {
        id: "block_b_1",
        name: "RDL com halteres",
        description: "Movimento de dobradiça do quadril. Mantenha as costas retas, empurre o quadril para trás e sinta o alongamento posterior.",
        image: "/src/assets/rdl_dumbbells.jpg",
        beginnerReps: "3x12-15",
        advancedReps: "4x8-12",
        videoUrl: "https://www.youtube.com/watch?v=tveTE065Ub0"
      },
      {
        id: "block_b_2",
        name: "Mesa flexora sentado/deitado",
        description: "Isolamento do posterior de coxa. Controle o movimento tanto na subida quanto na descida.",
        image: "/src/assets/leg_curl.jpg",
        beginnerReps: "3x12-15",
        advancedReps: "4x10-12",
        videoUrl: "https://www.youtube.com/watch?v=tveTE065Ub0"
      }
    ]
  },
  blockC: {
    title: "Bloco C – Hip Thrust (Glúteo foco)",
    exercises: [
      {
        id: "block_c_1",
        name: "Hip thrust com barra/Smith",
        description: "Exercício principal para glúteos. Apoie as costas no banco, empurre o quadril para cima contraindo os glúteos.",
        image: "/src/assets/hip_thrust.jpg",
        beginnerReps: "3x12-15",
        advancedReps: "4x8-12",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      },
      {
        id: "block_c_2",
        name: "Elevação pélvica com halter / máquina de glúteo",
        description: "Alternativa ao hip thrust. Foque na contração máxima dos glúteos no topo do movimento.",
        image: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&h=300&fit=crop",
        beginnerReps: "3x15-20",
        advancedReps: "4x12-15",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      }
    ]
  },
  blockD: {
    title: "Bloco D – Unilateral (Estabilidade)",
    exercises: [
      {
        id: "block_d_1",
        name: "Bulgarian Split Squat",
        description: "Exercício unilateral para força e estabilidade. Mantenha o peso na perna da frente e desça controladamente.",
        image: "/src/assets/bulgarian_split_squat.jpg",
        beginnerReps: "3x8-10 cada perna",
        advancedReps: "4x6-8 cada perna",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      },
      {
        id: "block_d_2",
        name: "Passada reversa no Smith",
        description: "Alternativa unilateral. Passo para trás controlado, focando na perna que fica à frente.",
        image: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&h=300&fit=crop",
        beginnerReps: "3x10-12 cada perna",
        advancedReps: "4x8-10 cada perna",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      }
    ]
  },
  blockE: {
    title: "Bloco E – Isolador de Posterior",
    exercises: [
      {
        id: "block_e_1",
        name: "Flexora sentado",
        description: "Isolamento específico do posterior de coxa. Controle total do movimento, sem usar impulso.",
        image: "/src/assets/leg_curl.jpg",
        beginnerReps: "3x12-15",
        advancedReps: "4x10-12",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      },
      {
        id: "block_e_2",
        name: "Flexora deitado",
        description: "Variação da flexora. Mantenha o quadril colado no banco e controle o movimento.",
        image: "/src/assets/leg_curl.jpg",
        beginnerReps: "3x12-15",
        advancedReps: "4x10-12",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      }
    ]
  },
  blockF: {
    title: "Bloco F – Glúteo Médio",
    exercises: [
      {
        id: "block_f_1",
        name: "Máquina abdutora",
        description: "Isolamento do glúteo médio. Movimento controlado, focando na contração lateral dos glúteos.",
        image: "/src/assets/hip_abductor.jpg",
        beginnerReps: "3x15-20",
        advancedReps: "4x12-15",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      },
      {
        id: "block_f_2",
        name: "Mini band sentado/apoio no banco",
        description: "Exercício com mini band para ativação do glúteo médio. Mantenha a tensão constante na banda.",
        image: "https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=400&h=300&fit=crop",
        beginnerReps: "3x15-20",
        advancedReps: "4x20-25",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      }
    ]
  },
  bonus: {
    title: "Bônus",
    exercises: [
      {
        id: "bonus_1",
        name: "Panturrilha em pé/sentado",
        description: "Fortalecimento das panturrilhas. Subida controlada na ponta dos pés, pausa no topo e descida lenta.",
        image: "/src/assets/calf_raise.jpg",
        beginnerReps: "3x15-20",
        advancedReps: "4x12-15",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      },
      {
        id: "bonus_2",
        name: "Caminhada inclinada leve (6–10 min)",
        description: "Finalização com caminhada leve para recuperação ativa e relaxamento muscular.",
        image: "/src/assets/treadmill_incline.png",
        beginnerReps: "6-8 min",
        advancedReps: "8-10 min",
        videoUrl: "https://www.youtube.com/watch?v=waAxlYvtCcI"
      }
    ]
  }
}

function App() {
  const [darkMode, setDarkMode] = useState(false)
  const [selectedExercises, setSelectedExercises] = useState({})
  const [completedExercises, setCompletedExercises] = useState(new Set())
  const [exerciseWeights, setExerciseWeights] = useState({})
  const [timerSeconds, setTimerSeconds] = useState(90)
  const [isTimerRunning, setIsTimerRunning] = useState(false)
  const [currentTimer, setCurrentTimer] = useState(0)

  // Inicializar exercícios selecionados (primeira opção de cada bloco)
  useEffect(() => {
    const initialSelection = {}
    Object.keys(exerciseData).forEach(blockKey => {
      initialSelection[blockKey] = 0 // Primeira opção (índice 0)
    })
    setSelectedExercises(initialSelection)
  }, [])

  // Timer effect
  useEffect(() => {
    let interval = null
    if (isTimerRunning && currentTimer > 0) {
      interval = setInterval(() => {
        setCurrentTimer(timer => timer - 1)
      }, 1000)
    } else if (currentTimer === 0 && isTimerRunning) {
      setIsTimerRunning(false)
      // Aqui poderia adicionar um som de notificação
    }
    return () => clearInterval(interval)
  }, [isTimerRunning, currentTimer])

  const toggleDarkMode = () => {
    setDarkMode(!darkMode)
    document.documentElement.classList.toggle('dark')
  }

  const toggleExercise = (blockKey) => {
    const currentIndex = selectedExercises[blockKey] || 0
    const maxIndex = exerciseData[blockKey].exercises.length - 1
    const newIndex = currentIndex === maxIndex ? 0 : currentIndex + 1
    
    setSelectedExercises(prev => ({
      ...prev,
      [blockKey]: newIndex
    }))
  }

  const toggleCompleted = (exerciseId) => {
    const newCompleted = new Set(completedExercises)
    if (newCompleted.has(exerciseId)) {
      newCompleted.delete(exerciseId)
    } else {
      newCompleted.add(exerciseId)
    }
    setCompletedExercises(newCompleted)
  }

  const updateWeight = (exerciseId, weight) => {
    setExerciseWeights(prev => ({
      ...prev,
      [exerciseId]: weight
    }))
  }

  const startTimer = (seconds) => {
    setCurrentTimer(seconds)
    setIsTimerRunning(true)
  }

  const stopTimer = () => {
    setIsTimerRunning(false)
  }

  const resetTimer = () => {
    setCurrentTimer(timerSeconds)
    setIsTimerRunning(false)
  }

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const ExerciseCard = ({ blockKey, blockData }) => {
    const selectedIndex = selectedExercises[blockKey] || 0
    const exercise = blockData.exercises[selectedIndex]
    const isCompleted = completedExercises.has(exercise.id)
    const weight = exerciseWeights[exercise.id] || ''

    return (
      <Card className={`transition-all duration-300 hover:shadow-lg ${isCompleted ? 'bg-green-50 dark:bg-green-900/20 border-green-500' : ''}`}>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-lg font-bold text-gray-900 dark:text-white">
                {blockData.title}
              </CardTitle>
              <CardDescription className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                {exercise.name}
              </CardDescription>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => toggleExercise(blockKey)}
              className="ml-2 text-xs"
            >
              <RefreshCw className="w-3 h-3 mr-1" />
              Trocar
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {/* Imagem do exercício */}
            <div className="relative overflow-hidden rounded-lg">
              <img 
                src={exercise.image} 
                alt={exercise.name}
                className="w-full h-48 object-cover"
                onError={(e) => {
                  e.target.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMzAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZGRkIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzk5OSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkltYWdlbSBuZGlzcG9uw612ZWw8L3RleHQ+PC9zdmc+'
                }}
              />
              {exercise.videoUrl && (
                <a 
                  href={exercise.videoUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300"
                >
                  <Play className="w-12 h-12 text-white" />
                </a>
              )}
            </div>

            {/* Descrição */}
            <p className="text-sm text-gray-700 dark:text-gray-300">
              {exercise.description}
            </p>

            {/* Séries e repetições */}
            <div className="flex gap-2">
              <Badge variant="secondary" className="text-xs">
                Iniciante: {exercise.beginnerReps}
              </Badge>
              <Badge variant="default" className="text-xs bg-green-600 hover:bg-green-700">
                Avançado: {exercise.advancedReps}
              </Badge>
            </div>

            {/* Controles */}
            <div className="flex items-center gap-3 pt-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id={exercise.id}
                  checked={isCompleted}
                  onCheckedChange={() => toggleCompleted(exercise.id)}
                />
                <label 
                  htmlFor={exercise.id}
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Concluído
                </label>
              </div>
              
              <div className="flex items-center space-x-2">
                <Dumbbell className="w-4 h-4" />
                <Input
                  type="text"
                  placeholder="Peso"
                  value={weight}
                  onChange={(e) => updateWeight(exercise.id, e.target.value)}
                  className="w-20 h-8 text-xs"
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'dark bg-gray-900' : 'bg-gray-50'}`}>
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                Treino de Pernas
              </h1>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Bruno & Namorada
              </p>
            </div>
            
            {/* Timer */}
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-gray-100 dark:bg-gray-700 rounded-lg px-3 py-2">
                <Timer className="w-4 h-4" />
                <span className="font-mono text-sm font-medium">
                  {formatTime(currentTimer)}
                </span>
                <div className="flex space-x-1">
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => startTimer(60)}
                    className="h-6 px-2 text-xs"
                  >
                    60s
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => startTimer(90)}
                    className="h-6 px-2 text-xs"
                  >
                    90s
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => startTimer(120)}
                    className="h-6 px-2 text-xs"
                  >
                    120s
                  </Button>
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={isTimerRunning ? stopTimer : () => startTimer(currentTimer || timerSeconds)}
                  className="h-6 px-2"
                >
                  {isTimerRunning ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={resetTimer}
                  className="h-6 px-2"
                >
                  <RotateCcw className="w-3 h-3" />
                </Button>
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleDarkMode}
                className="p-2"
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {Object.entries(exerciseData).map(([blockKey, blockData]) => (
            <ExerciseCard 
              key={blockKey} 
              blockKey={blockKey} 
              blockData={blockData} 
            />
          ))}
        </div>
      </main>
    </div>
  )
}

export default App
