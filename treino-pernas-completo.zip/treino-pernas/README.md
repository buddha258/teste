# Treino de Pernas - Bruno & Namorada

## Descrição
Site de treino de pernas com design fitness premium, desenvolvido em React com todas as funcionalidades solicitadas.

## Funcionalidades Implementadas

### ✅ Design e Visual
- **Visual limpo e motivador** com estilo fitness premium
- **Cores**: preto, cinza, branco + destaque em verde neon (#00ff41) e vermelho (#ff0040)
- **Layout em cards** para cada exercício
- **Modo claro/escuro** totalmente funcional
- **Responsivo** - funciona perfeitamente em desktop e mobile

### ✅ Exercícios e Estrutura
- **Aquecimento**: Esteira inclinada / Bike
- **Bloco A** - Agachamento Principal: Leg press 45° / Hack squat
- **Bloco B** - Hinge de Posterior: RDL com halteres / Mesa flexora
- **Bloco C** - Hip Thrust: Hip thrust com barra / Elevação pélvica
- **Bloco D** - Unilateral: Bulgarian Split Squat / Passada reversa
- **Bloco E** - Isolador de Posterior: Flexora sentado / Flexora deitado
- **Bloco F** - Glúteo Médio: Máquina abdutora / Mini band
- **Bônus**: Panturrilha / Caminhada inclinada

### ✅ Funcionalidades dos Cards
- **Nome do exercício** e descrição detalhada
- **Imagens específicas** para cada exercício (obtidas de fontes fitness profissionais)
- **Links para vídeos** do YouTube para demonstração
- **Séries/repetições** diferenciadas para iniciante (namorada) e avançado (Bruno)
- **Botão "Trocar por alternativa"** que alterna entre as opções de cada bloco

### ✅ Controles Interativos
- **Checkbox "Marcar como concluído"** (fica verde quando marcado)
- **Campo de anotação de peso** para cada exercício
- **Timer embutido** para descanso (60s, 90s, 120s configuráveis)
- **Controles do timer**: play/pause e reset

### ✅ Tecnologias Utilizadas
- **React 18** com hooks (useState, useEffect)
- **Tailwind CSS** para estilização
- **shadcn/ui** para componentes
- **Lucide React** para ícones
- **Vite** como bundler

## Como Executar

1. Navegue até o diretório do projeto:
```bash
cd treino-pernas
```

2. Instale as dependências (se necessário):
```bash
pnpm install
```

3. Execute o servidor de desenvolvimento:
```bash
pnpm run dev --host
```

4. Acesse no navegador: `http://localhost:5173`

## Estrutura do Projeto
```
treino-pernas/
├── src/
│   ├── assets/          # Imagens dos exercícios
│   ├── components/ui/   # Componentes UI (shadcn)
│   ├── App.jsx         # Componente principal
│   ├── App.css         # Estilos fitness premium
│   └── main.jsx        # Ponto de entrada
├── public/             # Arquivos públicos
├── index.html          # HTML principal
└── package.json        # Dependências
```

## Características Especiais

### Design Fitness Premium
- Gradientes neon com efeitos de brilho
- Animações suaves e transições
- Efeitos hover nos cards
- Scrollbar customizada
- Background com gradientes radiais

### Responsividade
- Grid adaptativo (3 colunas em desktop, 1 em mobile)
- Componentes que se ajustam ao tamanho da tela
- Touch-friendly em dispositivos móveis

### Experiência do Usuário
- Interface intuitiva e fácil de usar
- Feedback visual para ações do usuário
- Timer funcional para controle de descanso
- Persistência visual do estado dos exercícios

## Status
✅ **Projeto Completo e Funcional**

Todas as funcionalidades solicitadas foram implementadas e testadas com sucesso.

